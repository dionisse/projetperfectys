self.assetsManifest = {
  "version": "fQxlKohG",
  "assets": [
    {
      "hash": "sha256-WeOKCkI7IdJHs2kCqsKgLfiWX4/sNPbaRUspOLefkCY=",
      "url": "_content/Perfecto.Shared.UI/background.png"
    },
    {
      "hash": "sha256-YH0os5IcRtr2kpkeJnRXfHtFBfAlD/VCgGCCj6hAR4k=",
      "url": "_content/Perfecto.Shared.UI/css/perfecto.css"
    },
    {
      "hash": "sha256-FrrTtczTUEHjkhc/zWRPC7CmxeXI0JCZGc1+76qQ8B4=",
      "url": "_content/Perfecto.Shared.UI/exampleJsInterop.js"
    },
    {
      "hash": "sha256-9z2Ctl+GIN56ERFQXi8Gq4PlDWlcTdUZeyQRGge2sb8=",
      "url": "_content/Perfecto.Shared.UI/perfecto-mark.png"
    },
    {
      "hash": "sha256-zmQV9JYhv7uyV099OGXclWR7zfspuS4flURjsVGmtRY=",
      "url": "_framework/Microsoft.AspNetCore.Components.2wjqob5xi6.wasm"
    },
    {
      "hash": "sha256-r6bmf5erSxxmPodCX+hfcOlLptWy0AW3nojgutsF8eM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.v83hs8kyue.wasm"
    },
    {
      "hash": "sha256-0WXbhvlIYEf61fZAL2TmxHkOMBiV1GuYXVTbWM1ERZU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.vcuu1pg49m.wasm"
    },
    {
      "hash": "sha256-WhPyhEjFt2m6Qymhw13m2YTTg9rVl4E7Onwg+q7ETTc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.q3i8vs3hcq.wasm"
    },
    {
      "hash": "sha256-oDcpyYbqdkq6hP6NijTRWyXx2c2DKL6qilKSIzNmK3I=",
      "url": "_framework/Microsoft.Extensions.Configuration.47mkb8d5uo.wasm"
    },
    {
      "hash": "sha256-ZMSiWFGZbJVZPj28eku0yZNbnGhFfzFj6gpep+3y9tw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.488ris6j7m.wasm"
    },
    {
      "hash": "sha256-o5L9N1UOhqfOacmjcz9QfaqDLjHJf5HS/F+zQk1y9Ko=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.tsl8t8fg2u.wasm"
    },
    {
      "hash": "sha256-5DlYThGE5hm5bb5HOqKy2HSzGiuJQ3cvWQy/yPtt1J4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.wjxlhe8cg7.wasm"
    },
    {
      "hash": "sha256-HA794oey9tnbxPmEPxnLeVpNnd9Ez3NCmXHHuP961+Q=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.cum1owb24o.wasm"
    },
    {
      "hash": "sha256-OcjvqavRSEq7aLkkfXs7LhJHQ0QKjilkSs0cgjJEgx0=",
      "url": "_framework/Microsoft.Extensions.Logging.3lly2ppfku.wasm"
    },
    {
      "hash": "sha256-3HQaacomn0lKMXsAneYEo0N6oletE5ZH0pyNPOHss4o=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.8tcw0by9at.wasm"
    },
    {
      "hash": "sha256-Cb23UqG7cGF5BQcY7t9uQF93CxmshSCFl7gYh338cN8=",
      "url": "_framework/Microsoft.Extensions.Options.1y8ng0246k.wasm"
    },
    {
      "hash": "sha256-rxHDRuDvkgr8ovvNhTAPo1R77aaj2ZdbtB1UhGxSITk=",
      "url": "_framework/Microsoft.Extensions.Primitives.53666huos5.wasm"
    },
    {
      "hash": "sha256-TK3Xy49U+4dTqlEspjwdT40vizlUfenmda1wqHw7JAg=",
      "url": "_framework/Microsoft.JSInterop.4exx6oqbic.wasm"
    },
    {
      "hash": "sha256-tWu37j/RoE6Pwu6s46idTVIaPuEWCkAbsWSyzgKFWXI=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.vjcfjtelwd.wasm"
    },
    {
      "hash": "sha256-Vfu+FeWQr3NXXSXlBn3tfwRK1X5jnThUjyxbzIz1GKQ=",
      "url": "_framework/Perfecto.Application.1t4oxnxdhw.wasm"
    },
    {
      "hash": "sha256-ckSXd1dFslqpKzwCK8td/+y5chRilXxvMpJEwRHW1qk=",
      "url": "_framework/Perfecto.Contracts.i7s3uvpzoe.wasm"
    },
    {
      "hash": "sha256-tIpaZFpgHSAltfNA7s2t/HsUX3lR8lDhH0K1nL5aMBM=",
      "url": "_framework/Perfecto.Domain.c22t3me8qc.wasm"
    },
    {
      "hash": "sha256-krTr7+PKBgUfurUjNFKNMkbz64r8fW6g6HlVQqaFua8=",
      "url": "_framework/Perfecto.Pwa.edrczf8295.wasm"
    },
    {
      "hash": "sha256-gnmJyyyfW2NPIWnkqmQTU5sdaVKcbV22kNMec1fLAJ4=",
      "url": "_framework/Perfecto.Shared.UI.am686493hz.wasm"
    },
    {
      "hash": "sha256-vPEm2KqgXqruGwnz718iSgmDoB8Img7iH3FzO57b0Rg=",
      "url": "_framework/System.400l3mulw9.wasm"
    },
    {
      "hash": "sha256-V3fs4Kq3/GKx4jnaCu9TFSiqxoT2Ra1S9SssUx2m5I8=",
      "url": "_framework/System.Collections.Concurrent.9s71r8ll2w.wasm"
    },
    {
      "hash": "sha256-ZJfikvI/CdWMpR4yUDtRzjOoFkFES+r0noc0LIRuZEg=",
      "url": "_framework/System.Collections.Immutable.gvj4rccrhk.wasm"
    },
    {
      "hash": "sha256-riuXH4ihfobLOIaugvAaKP6T4/R6fyY2KqkjTIhEcrk=",
      "url": "_framework/System.Collections.NonGeneric.6j22nd9shy.wasm"
    },
    {
      "hash": "sha256-eYNfslkzV4agYzeWay86/0yIUMkqrw4cKtnITCNhYWA=",
      "url": "_framework/System.Collections.Specialized.zhcxj7970r.wasm"
    },
    {
      "hash": "sha256-RSYEQ9AWD76mkMRCBkOAinPuwEYaeZTuSmpj9toj6wg=",
      "url": "_framework/System.Collections.bckv5jtx8a.wasm"
    },
    {
      "hash": "sha256-rbwIhzSTagGN8HCEX6PUtTDWsl5DdsPspBg41mt4REk=",
      "url": "_framework/System.ComponentModel.Primitives.7fbuifkmew.wasm"
    },
    {
      "hash": "sha256-W78jiq6WpTglCm7WHrsdr/i/PyC6ymGgtja3GJ2pouw=",
      "url": "_framework/System.ComponentModel.TypeConverter.nxqwzzclfu.wasm"
    },
    {
      "hash": "sha256-rmHX/vP8IHgIBRQl6c1mYGutMGDOL9irayG03Yuadg8=",
      "url": "_framework/System.ComponentModel.iv4cyr9ulo.wasm"
    },
    {
      "hash": "sha256-2qgEgEr7JfJodJvLg1+ZWX4cNfMMdI2S3cshrAsFZL8=",
      "url": "_framework/System.Console.q8ev7i2p5x.wasm"
    },
    {
      "hash": "sha256-q/jgfoiBTlbbwc6p6AVHM5qGJ+bLinzczAyW/2VI65o=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.x5gmgvmnsf.wasm"
    },
    {
      "hash": "sha256-fZpB2NFmoDJXAqnCYU4+XAKkZbE51ViM3KsQ+bxqVOo=",
      "url": "_framework/System.IO.Pipelines.px0vglstfo.wasm"
    },
    {
      "hash": "sha256-W8K5k6Jycg4sDL305p8f1KVZukjk8jKWOyH3hbNWdvY=",
      "url": "_framework/System.Linq.Expressions.3qrwe0m9kv.wasm"
    },
    {
      "hash": "sha256-iTR1FVI1pNLRYMDclsK/1qax2p7gxwBk5sF7M3edfBw=",
      "url": "_framework/System.Linq.fiif8i3okv.wasm"
    },
    {
      "hash": "sha256-PhI2CLOQF6zzI7lUDWB3l9+I/gMUz6/s2aiaa34sAe8=",
      "url": "_framework/System.Memory.y0ur13t3pd.wasm"
    },
    {
      "hash": "sha256-G29YkhTlAkmweVa2WFjfdao4+DSUhVIjmPWMcWCWzHc=",
      "url": "_framework/System.Net.Http.5snehk6p68.wasm"
    },
    {
      "hash": "sha256-2Yx5zOLPM7HREa03J1CCifRFn8Ru8hvHEf5FOtHQ9zE=",
      "url": "_framework/System.Net.Primitives.f2xjda7duw.wasm"
    },
    {
      "hash": "sha256-rQa5SJdM0RWdGdQYm2qqVboB2KqKc0/fPFYNFrAOQNg=",
      "url": "_framework/System.ObjectModel.vprghyx63l.wasm"
    },
    {
      "hash": "sha256-aFd1rJnnQ9+MWdgIvxNKzY9DR8SpXzzg8lYCqSalnj4=",
      "url": "_framework/System.Private.CoreLib.oomjjv2nuy.wasm"
    },
    {
      "hash": "sha256-8o/Gh4HcexAAkOlQteY9+ZSn5hZL6NrOEL5rRxUOY+8=",
      "url": "_framework/System.Private.Uri.6jsyjmwrev.wasm"
    },
    {
      "hash": "sha256-tduEOm8vM6FbNtB5Yv4i6eyWWKqthWU2gcHRaPoIouQ=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.d22d4fjl8h.wasm"
    },
    {
      "hash": "sha256-zYAp8xLvtlOxalhozgdd7lV0l9NwVhdU3rOeT47LDIY=",
      "url": "_framework/System.Runtime.InteropServices.zsicxx3i3w.wasm"
    },
    {
      "hash": "sha256-q5UODsc5ZSRlSMmXVEh6BiIn00azGq4/bC+5N9nc7gY=",
      "url": "_framework/System.Runtime.Serialization.Primitives.b45z9iqzpn.wasm"
    },
    {
      "hash": "sha256-1q/7Aql6KMEss2AoyweB0mLrtuWv2c1rvPcvUphe4gg=",
      "url": "_framework/System.Runtime.mwov0c35h0.wasm"
    },
    {
      "hash": "sha256-cTpFIxaNUWLXKQa2yGmNxTQNwgdyj7W4RAOSXRdsk50=",
      "url": "_framework/System.Security.Cryptography.r9ft3wvid9.wasm"
    },
    {
      "hash": "sha256-EP5M39kjuYI2pqT4UtWA6NQXV8hK4VIL6IKShuCuLPw=",
      "url": "_framework/System.Text.Encodings.Web.wohquxuxoe.wasm"
    },
    {
      "hash": "sha256-UT9lGxTNQZ4ufzFlTuQUzmYxa3bDADGHuA7jwZtjHQA=",
      "url": "_framework/System.Text.Json.1054tg9pxx.wasm"
    },
    {
      "hash": "sha256-wuskkBhFKI5HuLswXYxchtR7Ox8rUKe6/MscBBo7zcg=",
      "url": "_framework/System.Text.RegularExpressions.aijkgveird.wasm"
    },
    {
      "hash": "sha256-lMktaVAwP6kmCllp0bIiqcsQCeEUhu/OzQdb5N5EC7U=",
      "url": "_framework/System.Threading.0lyqs7gy1f.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.w3qd1tpl0e.js"
    },
    {
      "hash": "sha256-E9hHWlYDdwDqxesvJU09i6UlPXBL5sxzCyXtSmL7fp0=",
      "url": "_framework/dotnet.9l7a3kb6se.js"
    },
    {
      "hash": "sha256-jZddobLBM2C3lQhYQ61xSQJ/WqD3eQCO3RzoHGaOjx0=",
      "url": "_framework/dotnet.native.b6l13xorvf.js"
    },
    {
      "hash": "sha256-JTxXd17wbrHKV/375moHFUFc3a/ofVTPPqSTk6KwNj0=",
      "url": "_framework/dotnet.native.rw4kynp763.wasm"
    },
    {
      "hash": "sha256-QbnqrZGHtGq7wudS17/AYEPpH9JkphrsyVllD6JHmds=",
      "url": "_framework/dotnet.runtime.v06hirbjsv.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-BX4uSd0+wCah6KwxuQqXRWcmzaKqTSIXZji64so15Zw=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-iyuyB5Kg0CWX129gnBSeV5uUPJ4aQfvI8IowMgsY9+0=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-SC211PDiB1k5sL/3lJ1ADPY5Y/0ZCbAbOVTF94KrIxI=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-2dxDYAlwRPmaQyK0s/XwL2JJv6iRAGo2CXeq2r8BkLs=",
      "url": "js/perfecto-db.js"
    },
    {
      "hash": "sha256-8F2tnnjAhNa9QWM5Jy83T+n/C7gki8jaemtoh4OC0cA=",
      "url": "manifest.webmanifest"
    }
  ]
};
